﻿Public Class frm_Producto_Alta

    Dim Producto_Actual As Producto

    '===========***Construuctores***=================================

    Public Sub New()

        'Se debe llamar a este método para que se generen los controles automáticamente
        InitializeComponent()

        ' Cualquier accion debe escribirse a partir de esta línea
        Preparar_Interfaz()

    End Sub
    '_____________________________________________________________

    Public Sub New(ByRef producto_parametro As Producto)

        InitializeComponent()

        Preparar_Interfaz()

        Producto_Actual = producto_parametro

        Clase_A_Interfaz()

    End Sub

    Sub Preparar_Interfaz()

        cmb_rubro.DataSource = Producto.Obtener_Rubros()
        cmb_rubro.ValueMember = "rubro_id"
        cmb_rubro.DisplayMember = "descripcion"

    End Sub

    '=============================================================

    '============ Métodos de ABM =================================

    Sub Clase_A_Interfaz()

        txt_codigo.Text = Producto_Actual.Codigo.ToString()
        txt_nombre.Text = Producto_Actual.Nombre
        txt_precio.Text = Producto_Actual.Precio.ToString()
        txt_stock.Text = Producto_Actual.Stock.ToString()
        dtp_fechaInicio.Value = Producto_Actual.FechaInicio
        cmb_rubro.SelectedValue = Producto_Actual.Rubro.ToString()

    End Sub

    Sub Interfaz_A_Clase()

        If (Producto_Actual Is Nothing) Then
            Producto_Actual = New Producto()
        End If

        Producto_Actual.Nombre = txt_nombre.Text
        Producto_Actual.Precio = Convert.ToDouble(txt_precio.Text)
        Producto_Actual.Rubro = Convert.ToInt32(cmb_rubro.SelectedValue)
        Producto_Actual.Stock = Convert.ToDouble(txt_stock.Text)
        Producto_Actual.FechaInicio = dtp_fechaInicio.Value

    End Sub

    Sub Guardar()

        Interfaz_A_Clase()

        If (Producto_Actual.Codigo = 0) Then

            Producto_Actual.Insertar()

        Else

            Producto_Actual.Actualizar()

        End If

        Clase_A_Interfaz()

        MessageBox.Show("El producto se ha registrado correctamente")

    End Sub

    Sub Eliminar()

        Producto_Actual.Eliminar()

        MessageBox.Show("El producto se ha eliminado")

        Me.Close()

    End Sub

    '=============================================================

    '=============Eventos Capturados==============================

    Private Sub btn_guardar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_guardar.Click

        Try

            Guardar()

        Catch ex As Exception

            MessageBox.Show(ex.Message)

        End Try

    End Sub

    Private Sub btn_Eliminar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Eliminar.Click
        Try

            Eliminar()

        Catch ex As Exception

            MessageBox.Show(ex.Message)

        End Try
    End Sub

    '=============================================================

End Class
