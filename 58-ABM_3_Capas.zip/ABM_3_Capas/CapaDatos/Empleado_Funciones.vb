﻿Public Class Empleado_Funciones

End Class
