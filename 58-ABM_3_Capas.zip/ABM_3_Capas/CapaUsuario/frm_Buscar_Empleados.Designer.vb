﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_Buscar_Empleados
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dgv_EmpleadosGRilla = New System.Windows.Forms.DataGridView
        Me.btn_Buscar = New System.Windows.Forms.Button
        Me.btn_Nuevo = New System.Windows.Forms.Button
        Me.btn_Editar = New System.Windows.Forms.Button
        Me.btn_Salir = New System.Windows.Forms.Button
        CType(Me.dgv_EmpleadosGRilla, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgv_EmpleadosGRilla
        '
        Me.dgv_EmpleadosGRilla.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_EmpleadosGRilla.Location = New System.Drawing.Point(12, 62)
        Me.dgv_EmpleadosGRilla.Name = "dgv_EmpleadosGRilla"
        Me.dgv_EmpleadosGRilla.Size = New System.Drawing.Size(609, 321)
        Me.dgv_EmpleadosGRilla.TabIndex = 0
        '
        'btn_Buscar
        '
        Me.btn_Buscar.Location = New System.Drawing.Point(444, 12)
        Me.btn_Buscar.Name = "btn_Buscar"
        Me.btn_Buscar.Size = New System.Drawing.Size(75, 44)
        Me.btn_Buscar.TabIndex = 1
        Me.btn_Buscar.Text = "Buscar"
        Me.btn_Buscar.UseVisualStyleBackColor = True
        '
        'btn_Nuevo
        '
        Me.btn_Nuevo.Location = New System.Drawing.Point(13, 28)
        Me.btn_Nuevo.Name = "btn_Nuevo"
        Me.btn_Nuevo.Size = New System.Drawing.Size(108, 23)
        Me.btn_Nuevo.TabIndex = 2
        Me.btn_Nuevo.Text = "Nuevo Empleado"
        Me.btn_Nuevo.UseVisualStyleBackColor = True
        '
        'btn_Editar
        '
        Me.btn_Editar.Location = New System.Drawing.Point(141, 28)
        Me.btn_Editar.Name = "btn_Editar"
        Me.btn_Editar.Size = New System.Drawing.Size(108, 23)
        Me.btn_Editar.TabIndex = 2
        Me.btn_Editar.Text = "Editar Empleado"
        Me.btn_Editar.UseVisualStyleBackColor = True
        '
        'btn_Salir
        '
        Me.btn_Salir.Location = New System.Drawing.Point(537, 12)
        Me.btn_Salir.Name = "btn_Salir"
        Me.btn_Salir.Size = New System.Drawing.Size(75, 44)
        Me.btn_Salir.TabIndex = 3
        Me.btn_Salir.Text = "Salir"
        Me.btn_Salir.UseVisualStyleBackColor = True
        '
        'frm_Buscar_Empleados
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(633, 395)
        Me.Controls.Add(Me.btn_Salir)
        Me.Controls.Add(Me.btn_Editar)
        Me.Controls.Add(Me.btn_Nuevo)
        Me.Controls.Add(Me.btn_Buscar)
        Me.Controls.Add(Me.dgv_EmpleadosGRilla)
        Me.Name = "frm_Buscar_Empleados"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Buscar"
        CType(Me.dgv_EmpleadosGRilla, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents dgv_EmpleadosGRilla As System.Windows.Forms.DataGridView
    Friend WithEvents btn_Buscar As System.Windows.Forms.Button
    Friend WithEvents btn_Nuevo As System.Windows.Forms.Button
    Friend WithEvents btn_Editar As System.Windows.Forms.Button
    Friend WithEvents btn_Salir As System.Windows.Forms.Button
End Class
