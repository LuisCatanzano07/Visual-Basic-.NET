﻿Public Class frm_Producto_Buscar
    '=========== EVENTOS ==================================================

    Private Sub btn_editar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_editar.Click

        Try

            Editar_Producto()

        Catch ex As Exception

            MessageBox.Show("Error al abrir el producto")

        End Try

    End Sub

    Private Sub btn_Nuevo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Nuevo.Click

        Nuevo_Producto()

    End Sub

    

    Private Sub btn_buscar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_buscar.Click

        Try
            Buscar()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub

    '======================================================================

    '====== METODOS =======================================================

    Sub Buscar()

        Dim text_buscado = txt_nombre.Text
        Dim rubro_id = Convert.ToInt32(cmb_rubro.SelectedValue)

        DataGridView1.DataSource = Producto.Buscar(text_buscado, rubro_id)



    End Sub

    Sub Prepara_Interfaz()

        cmb_rubro.DataSource = Producto.Obtener_Rubros()
        cmb_rubro.DisplayMember = "descripcion"
        cmb_rubro.ValueMember = "rubro_id"

    End Sub

    Sub Nuevo_Producto()

        Dim frm = New frm_Producto_Alta()
        frm.MdiParent = Me.MdiParent
        frm.Show()

    End Sub

    Sub Editar_Producto()

        Dim codigo = Convert.ToInt32(DataGridView1.SelectedRows(0).Cells("producto_id").Value)

        Dim producto_seleccionado As New Producto(codigo)

        Dim frm = New frm_Producto_Alta(producto_seleccionado)
        frm.MdiParent = Me.MdiParent
        frm.Show()


    End Sub

    '=============================================================

    '======= CONSTRUCTORES =======================================

    Public Sub New()

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        Try

            Prepara_Interfaz()

        Catch ex As Exception

            MessageBox.Show("No se pudo preparar la interfaz")

        End Try


    End Sub

    '=============================================================
    
   
   
    
    Private Sub btn_Eliminar_Click(sender As System.Object, e As System.EventArgs) Handles btn_Eliminar.Click
        Dim Codigo = Convert.ToInt32(DataGridView1.SelectedRows(0).Cells(0).Value)
        Dim Producto_Seleccionado As New Producto(Codigo)
        Producto_Seleccionado.Eliminar()
        Buscar()

    End Sub
End Class