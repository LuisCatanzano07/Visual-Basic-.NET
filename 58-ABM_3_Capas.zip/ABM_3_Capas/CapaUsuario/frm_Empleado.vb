﻿Imports CapaNegocio

Public Class frm_Empleado

    Dim empleado_formulario As New CapaNegocio.Empleado

    Private Sub btn_Guardar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Guardar.Click

        Try
            'Llamo a la rutina "Guardar"
            Guardar()

            MessageBox.Show("Transacción exitosa", "Confirmación", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error al Guardar Empleado", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Public Sub Guardar()

        'Si el objeto global del formulario "empleado_formulario" es nulo, osea que 
        'aun no fue contruido (o instanciado), entonces se instancia para poder ser usado.
        If (empleado_formulario Is Nothing) Then
            empleado_formulario = New CapaNegocio.Empleado()
        End If

        'Se lee cada campo del formulario y se asigna el valor de ellos a su correspondiente
        ' atributo en el objeto "empleado_formulario"

        empleado_formulario.Nombre = txt_Nombre.Text
        empleado_formulario.Apellido = txt_Apellido.Text
        empleado_formulario.Edad = txt_Edad.Text

        empleado_formulario.Area_ID = Convert.ToInt32(cmb_Area.SelectedValue)

        'Se ejecuta el método Guardar_Empleado del objeto Empleado.
        empleado_formulario.Guardar_Empleado()

        'Al guardar un nuevo registro, se obtiene un nuevo ID generado por la base
        ' se lo lee y se lo muestra en la interfaz
        txt_Codigo.Text = empleado_formulario.Codigo.ToString()

    End Sub

    'Constuctor Vacio, se utiliza en el momento de llamar al formulario con la intención de 
    'crear un nuevo registro
    Public Sub New()

        InitializeComponent()

        Preparar_Interfaz()

    End Sub

    'Constructor con Parámetro, recibe un objeto de la Clase CapaNegocio.Empleado
    'para que muestre sus datos en la pantalla
    Public Sub New(ByRef empleado_parametro As CapaNegocio.Empleado)

        InitializeComponent()

        Preparar_Interfaz()

        'Tomo el objeto enviado por el parámetro, y lo asigno al objeto declarado globalment
        ' en el formulario para que pueda estar accesible desde cualquier lugar 
        'del formulario
        empleado_formulario = empleado_parametro

        'Llamo a la rutina que toma los atributos del objeto enviado por parámetro, 
        'y lo muestra en la pantalla.
        Clase_A_Interfaz()

    End Sub

    Sub Preparar_Interfaz()

        cmb_Area.DataSource = CapaNegocio.Empleado.Areas_De_La_Empresa()
        cmb_Area.DisplayMember = "area"
        cmb_Area.ValueMember = "codigo"

    End Sub

    Sub Clase_A_Interfaz()

        txt_Codigo.Text = empleado_formulario.Codigo.ToString()
        txt_Nombre.Text = empleado_formulario.Nombre
        txt_Apellido.Text = empleado_formulario.Apellido
        txt_Edad.Text = empleado_formulario.Edad

        cmb_Area.SelectedValue = empleado_formulario.Area_ID

    End Sub

    Private Sub txt_Codigo_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txt_Codigo.GotFocus
        txt_Nombre.Focus()
    End Sub

    Private Sub btn_Salir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Salir.Click
        Me.Close()
    End Sub

   
End Class
