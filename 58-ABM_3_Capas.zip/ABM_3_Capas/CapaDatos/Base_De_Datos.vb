﻿Imports System.Data.OleDb

Public Class Base_De_Datos

    'Devuelve una conexion de la base de datos Abierta
    Public Shared Function Obtener_Conexion() As OleDbConnection

        Dim conexion As New OleDbConnection(My.Settings.My_DataBase)
        'My_DataBase: Depende de cada uno como le llamó

        conexion.Open()

        Return conexion

    End Function

    'Ejecuta un comando recibiendo como parámetro un objeto OleDbCommand
    Public Shared Sub Ejecutar_Comando(ByRef comando As OleDbCommand)

        comando.Connection = Obtener_Conexion()

        comando.ExecuteNonQuery()

    End Sub

    'Ejecuta un comando sql recibiendo como parámetro:
    '- Comando en String, la estructura del comando SQL.
    '- Lista de Parámetros (OleDbParameter) para reemplazar los "@" por valores.
    Public Shared Sub Ejecutar_Comando(ByVal comando_sql As String, ByRef parametros As List(Of OleDbParameter))

        Dim comando As New OleDbCommand(comando_sql, Obtener_Conexion())

        If Not (parametros Is Nothing) Then

            For index As Integer = 0 To parametros.Count - 1

                comando.Parameters.Add(parametros.ElementAt(index))

            Next

        End If

        comando.ExecuteNonQuery()

    End Sub

    'Ejecuta una consulta sql y devuelve un DataTable recibiendo como parámetro:
    '- Consulta SQL en String, la estructura del comando SQL.
    '- Lista de Parámetros (OleDbParameter) para reemplazar los "@" por valores.
    Public Shared Function Obtener_Tabla(ByVal comando_sql As String, ByRef parametros As List(Of OleDbParameter)) As DataTable

        Dim comando As New OleDbCommand(comando_sql, Obtener_Conexion())

        If Not (parametros Is Nothing) Then

            For index As Integer = 0 To parametros.Count - 1

                comando.Parameters.Add(parametros.ElementAt(index))

            Next

        End If

        Dim da As New OleDbDataAdapter(comando)
        Dim dt As New DataTable()

        da.Fill(dt)

        Return dt

    End Function

    'Esta función devuelve el último ID generado en la base de datos;
    ' es frecuente usar este método luego de un insert.
    Public Shared Function Obtener_Ultimo_ID_Generado() As Integer

        Dim select_sql = "SELECT @@IDENTITY"

        Dim tb = Obtener_Tabla(select_sql, Nothing)

        Return Convert.ToInt32(tb.Rows(0)(0))

    End Function

End Class
