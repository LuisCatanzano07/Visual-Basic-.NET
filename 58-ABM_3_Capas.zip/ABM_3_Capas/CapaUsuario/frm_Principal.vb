﻿Public Class frm_Principal

    Private Sub BusquedaDeEmpleadosToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BusquedaDeEmpleadosToolStripMenuItem.Click
        Dim frm = New frm_Buscar_Empleados()
        frm.MdiParent = Me
        frm.Show()
    End Sub

    Private Sub AltaDeEmpleadosToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AltaDeEmpleadosToolStripMenuItem.Click
        Dim frm = New frm_Empleado()
        frm.MdiParent = Me
        frm.Show()
    End Sub

    Private Sub SalirToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SalirToolStripMenuItem.Click
        End
    End Sub
End Class