﻿'En esta Clase, se programan los métodos estáticos que suministran la funcionalidad de
' la conexion a los datos de la clase Capa_Negocio.Empleado
' Esta es la clase que generará la conexion a los datos y maneja las solicitudes de 
' transacciones SQL
Public Class Funciones_Empleado

    Public Shared Function Guardar_Nuevo_Empleado(ByVal nombre As String, ByVal apellido As String, ByVal edad As Integer, ByVal area_id As Integer) As Integer

        Dim insertar_sql = "INSERT INTO Empleados (nombre, apellido, edad, area_id) VALUES (@nombre, @apellido, @edad,@area_id)"

        Dim parametros As New List(Of OleDb.OleDbParameter)

        parametros.Add(New OleDb.OleDbParameter("nombre", nombre))
        parametros.Add(New OleDb.OleDbParameter("apellido", apellido))
        parametros.Add(New OleDb.OleDbParameter("edad", edad))
        parametros.Add(New OleDb.OleDbParameter("area_id", area_id))

        Base_De_Datos.Ejecutar_Comando(insertar_sql, parametros)

        Return Base_De_Datos.Obtener_Ultimo_ID_Generado()

    End Function

    Public Shared Sub Actualizar_Empleado(ByVal nombre As String, ByVal apellido As String, ByVal edad As Integer, ByVal area_id As Integer, ByVal codigo As Integer)

        Dim insertar_sql = "UPDATE Empleados SET nombre=@nombre, apellido=@apellido, edad=@edad, area_id=@area_id WHERE codigo=@codigo"

        Dim parametros As New List(Of OleDb.OleDbParameter)

        parametros.Add(New OleDb.OleDbParameter("nombre", nombre))
        parametros.Add(New OleDb.OleDbParameter("apellido", apellido))
        parametros.Add(New OleDb.OleDbParameter("edad", edad))
        parametros.Add(New OleDb.OleDbParameter("codigo", codigo))

        parametros.Add(New OleDb.OleDbParameter("area_id", area_id))

        Base_De_Datos.Ejecutar_Comando(insertar_sql, parametros)

    End Sub

    Public Shared Function Buscar_Empleados() As DataTable

        Dim select_sql = "SELECT * FROM Empleados"

        Return Base_De_Datos.Obtener_Tabla(select_sql, Nothing)

    End Function

    Public Shared Function Fila_De_Empleado(ByVal codigo As Integer) As DataRow

        Dim select_sql = "SELECT * FROM Empleados WHERE codigo=@codigo"
        Dim parametros As New List(Of OleDb.OleDbParameter)
        parametros.Add(New OleDb.OleDbParameter("@codigo", codigo))

        Dim dt = Base_De_Datos.Obtener_Tabla(select_sql, parametros)

        If (dt.Rows.Count = 0) Then
            Throw New Exception("No existe ningun empleado con ese código")
        End If

        Return dt.Rows(0)

    End Function

    Public Shared Function Areas_Disponibles() As DataTable

        Dim select_sql = "SELECT * FROM Areas ORDER BY Area ASC"

        Return Base_De_Datos.Obtener_Tabla(select_sql, Nothing)

    End Function
   


End Class
