﻿Imports System.Data.OleDb
Public Class Producto

    '===========================================================================================
    Private _codigo As Integer
    Private _nombre As String
    Private _rubro As Integer
    Private _stock As Double
    Private _fechaInicio As DateTime
    Private _precio As Double

    Public Property Codigo() As Integer
        Get
            Return _codigo
        End Get
        Set(ByVal value As Integer)
            _codigo = value
        End Set
    End Property
    Public Property Nombre() As String
        Get
            Return _nombre
        End Get
        Set(ByVal value As String)
            _nombre = value
        End Set
    End Property
    Public Property Rubro() As Integer
        Get
            Return _rubro
        End Get
        Set(ByVal value As Integer)
            _rubro = value
        End Set
    End Property
    Public Property Precio() As Double
        Get
            Return _precio
        End Get
        Set(ByVal value As Double)
            _precio = value
        End Set
    End Property
    Public Property Stock() As Double
        Get
            Return _stock
        End Get
        Set(ByVal value As Double)
            _stock = value
        End Set
    End Property
    Public Property FechaInicio() As DateTime
        Get
            Return _fechaInicio
        End Get
        Set(ByVal value As DateTime)
            _fechaInicio = value
        End Set
    End Property

    '===========================================================================================

    Public Function Insertar() As Integer


        'Declaro una variable tipo String que contiene la ESTRUCTURA de la sentencia SQL
        'La sentencia SQL INSERT es la que inserta un nuevo registro en la tabla especificada.        
        Dim cmd_insertar = "INSERT INTO Productos (nombre, rubro_id , precio, stock, fechaInicioComercial) " _
                         & " VALUES (@nombre, @rubro_id , @precio, @stock, @fechaInicioComercial)"

        'Declaro una variable tipo OleDbConnetion y la contruyo enviando la cadena de conexión.
        'En este caso, la cadena de conexión está configurada en las "settings" de la aplicación
        Dim conexion = New OleDbConnection(My.Settings.My_DataBase)

        'Abro la conexión a la base de datos
        conexion.Open()

        'Declaro una variable tipo OleDbCommand para ejecutar el comando especificado anteriormente ("cmd_insertar")
        'Construyo la variable enviando la conexión ("cmd_insertar") y el comando SQL ("conexion")
        Dim comando As New OleDbCommand(cmd_insertar, conexion)


        'Por medio de los siguientes pasos, se le especifica a cada parámetro de la sentencia SQL que debe ser reemplazado por
        'los valores que se especifican en cada caso.
        comando.Parameters.Add(New OleDbParameter("@nombre", Me.Nombre))
        comando.Parameters.Add(New OleDbParameter("@rubro_id", Me.Rubro))
        comando.Parameters.Add(New OleDbParameter("@precio", Me.Precio))
        comando.Parameters.Add(New OleDbParameter("@stock", Me.Stock))
        comando.Parameters.Add(New OleDbParameter("@fechaInicioComercial", Me.FechaInicio))


        'Se ejecuta la sentencia SQL en la base de datos. Este método devuelve un número entero que significa cuantos registros
        'han sido afectados por la sentencia SQL.
        comando.ExecuteNonQuery()


        'Obtengo el ultimo ID generado automáticamente en la base de datos
        Dim cmd_select = "select @@identity"
        comando = New OleDbCommand(cmd_select, conexion)
        Dim dt = New DataTable()
        Dim da = New OleDbDataAdapter(comando)
        da.Fill(dt)
        Me.Codigo = Convert.ToInt32(dt.Rows(0)(0)) 'Obtengo el valor y se lo asigno al atributo Codigo.


        'Cierro la conexión a la base de datos
        conexion.Close()

        'Devuelvo el código generado automáticamente tras la inserción en la tabla
        Return Me.Codigo

    End Function

    '===========================================================================================

    Public Sub Actualizar()

        Dim cmd_update = "UPDATE Productos SET (nombre=@nombre, rubro_id=@rubro_id, precio=@precio, stock=@stock, fechaInicioComercial=@fechaInicioComercial) WHERE producto_id=@producto_id"

        Dim conexion = New OleDbConnection(My.Settings.My_DataBase)
        conexion.Open()

        Dim comando As New OleDbCommand(cmd_update, conexion)

        comando.Parameters.Add(New OleDbParameter("@nombre", Me.Nombre))
        comando.Parameters.Add(New OleDbParameter("@rubro_id", Me.Rubro))
        comando.Parameters.Add(New OleDbParameter("@precio", Me.Precio))
        comando.Parameters.Add(New OleDbParameter("@stock", Me.Stock))
        comando.Parameters.Add(New OleDbParameter("@fechaInicioComercial", Me.FechaInicio))
        comando.Parameters.Add(New OleDbParameter("@producto_id", Me.Codigo))

        comando.ExecuteNonQuery()
        conexion.Close()

    End Sub

    '===========================================================================================

    Public Shared Function Buscar(ByVal nombre_par As String, ByVal rubro_par As Integer) As DataTable

        Dim cmd_select = "SELECT * FROM Vista_Productos WHERE nombre LIKE @nombre "

        Dim busca_rubro = False

        If rubro_par <> 0 Then

            cmd_select += " AND rubro_id=@rubro_id"

            busca_rubro = True

        End If


        Dim conexion = New OleDbConnection(My.Settings.My_DataBase)
        conexion.Open()

        Dim comando As New OleDbCommand(cmd_select, conexion)

        comando.Parameters.Add(New OleDbParameter("@nombre", "%" & nombre_par & "%"))


        If busca_rubro Then
            comando.Parameters.Add(New OleDbParameter("@rubro_id", rubro_par))
        End If

        Dim dt = New DataTable()

        Dim da = New OleDbDataAdapter(comando)

        da.Fill(dt)

        Return dt

    End Function

    '===========================================================================================

    Public Sub Eliminar()

        Dim cmd_update = "DELETE FROM Productos WHERE producto_id=@producto_id"

        Dim conexion = New OleDbConnection(My.Settings.My_DataBase)
        conexion.Open()

        Dim comando As New OleDbCommand(cmd_update, conexion)

        comando.Parameters.Add(New OleDbParameter("@producto_id", Me.Codigo))

        comando.ExecuteNonQuery()
        conexion.Close()

    End Sub

    '===========================================================================================

    Public Shared Function Obtener_Rubros() As DataTable

        Dim cmd_select = "SELECT * FROM Rubros"

        Dim conexion = New OleDbConnection(My.Settings.My_DataBase)
        conexion.Open()

        Dim comando As New OleDbCommand(cmd_select, conexion)

        Dim dt = New DataTable()

        Dim da = New OleDbDataAdapter(comando)

        da.Fill(dt)

        Return dt

    End Function

    '===========================================================================================

    Public Sub New()

    End Sub

    '===========================================================================================

    Public Sub New(ByVal codigo_par As Integer)

        Dim cmd_select = "SELECT * FROM Productos WHERE producto_id = @producto_id "

        Dim conexion = New OleDbConnection(My.Settings.My_DataBase)
        conexion.Open()

        Dim comando As New OleDbCommand(cmd_select, conexion)

        comando.Parameters.Add(New OleDbParameter("@producto_id", codigo_par))

        Dim dt = New DataTable()

        Dim da = New OleDbDataAdapter(comando)

        da.Fill(dt)

        Me.Codigo = Convert.ToInt32(dt.Rows(0)("producto_id"))
        Me.Nombre = Convert.ToString(dt.Rows(0)("nombre"))
        Me.Rubro = Convert.ToInt32(dt.Rows(0)("rubro_id"))
        Me.Precio = Convert.ToDouble(dt.Rows(0)("precio"))
        Me.Stock = Convert.ToDouble(dt.Rows(0)("stock"))
        Me.FechaInicio = Convert.ToDateTime(dt.Rows(0)("fechaInicioComercial"))

    End Sub

    '===========================================================================================
End Class
