﻿Public Class frm_Menu_Principal

    Private Sub BuscarProductosToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BuscarProductosToolStripMenuItem.Click

        Dim frm = New frm_Producto_Buscar()
        frm.MdiParent = Me
        frm.Show()

    End Sub

    Private Sub NuevoProductoToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NuevoProductoToolStripMenuItem.Click

        Dim frm = New frm_Producto_Alta()
        frm.MdiParent = Me
        frm.Show()

    End Sub
End Class