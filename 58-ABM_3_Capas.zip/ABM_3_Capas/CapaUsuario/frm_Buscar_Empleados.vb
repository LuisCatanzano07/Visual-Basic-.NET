﻿Imports CapaNegocio

Public Class frm_Buscar_Empleados

    Private Sub btn_Buscar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Buscar.Click
        Try
            'Llamo a la rutina Buscar()
            Buscar()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Public Sub Buscar()

        'El "DataSource de la grilla es alimentado con un DataTable 
        'que proviene de la clase "Empleado" que está en el namespace "CapaNegocio"

        dgv_EmpleadosGRilla.DataSource = CapaNegocio.Empleado.Buscar_Empleados()

        ' Agregamos los textos del encabezado de cada columna del DataGridView

        dgv_EmpleadosGRilla.Columns("Codigo").HeaderText = "Código"
        dgv_EmpleadosGRilla.Columns("nombre").HeaderText = "Nombre"
        dgv_EmpleadosGRilla.Columns("apellido").HeaderText = "Apellido"
        dgv_EmpleadosGRilla.Columns("edad").HeaderText = "Edad"
        dgv_EmpleadosGRilla.Columns("area_id").HeaderText = "Código Area"

        ' Ajusta las columnas para que ocupen todo el control DataGridView

        dgv_EmpleadosGRilla.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
    End Sub

    Private Sub btn_Nuevo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Nuevo.Click

        Dim frm_nuevo As New frm_Empleado() 'Declaro una variable tipo frm_empleado
        frm_nuevo.MdiParent = Me.MdiParent
        frm_nuevo.Show() 'Hago el Show del formulario como diálogo

        'Luego de mostrar el formulario como díalogo, llamo a la rutina "Buscar" 
        'para que actualice la grilla con el nuevo registro dado de alta
        Buscar()
    End Sub

    Private Sub btn_Editar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Editar.Click

        Try
            Editar() 'Llamo a la rutina Editar
            Buscar() 'Luego de editar, hago que se actualice la grilla llamando a la rutina Buscar
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub

    Sub Editar()

        'Declaro una variable tipo Entera
        Dim codigo_seleccionado As Integer

        'Tomo la fila seleccionada de la grilla, en la columna "codigo", leo el Value y lo convierto en Entero.
        codigo_seleccionado = Convert.ToInt32(dgv_EmpleadosGRilla.SelectedRows(0).Cells("codigo").Value)


        'Declaro e instancio una variable tipo Empleado usando el 2do constructor (el que recibe un entero)
        Dim empleado_seleccionado As New CapaNegocio.Empleado(codigo_seleccionado)

        'Declaro un objeto tipo frm_Empleado (depende de cómo le llamaron al formulario de alta) usando el 2do constructor que recibe un objeto tipo Empleado
        Dim frm_editar As New frm_Empleado(empleado_seleccionado)
        frm_editar.MdiParent = Me.MdiParent
        'Muestro el formulario
        frm_editar.Show()

    End Sub

    Private Sub btn_Salir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Salir.Click
        Me.Close()
    End Sub

   
End Class