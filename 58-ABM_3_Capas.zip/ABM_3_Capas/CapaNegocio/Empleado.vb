﻿Imports CapaDatos

Public Class Empleado

    Private _Codigo As Integer
    Public Property Codigo() As Integer
        Get
            Return _Codigo
        End Get
        Set(ByVal value As Integer)
            _Codigo = value
        End Set
    End Property

    Private _Nombre As String
    Public Property Nombre() As String
        Get
            Return _Nombre
        End Get
        Set(ByVal value As String)
            _Nombre = value
        End Set
    End Property

    Private _Apellido As String
    Public Property Apellido() As String
        Get
            Return _Apellido
        End Get
        Set(ByVal value As String)
            _Apellido = value
        End Set
    End Property

    Private _Edad As Integer
    Public Property Edad() As Integer
        Get
            Return _Edad
        End Get
        Set(ByVal value As Integer)
            _Edad = value
        End Set
    End Property

    Private _Area_ID As Integer
    Public Property Area_ID() As Integer
        Get
            Return _Area_ID
        End Get
        Set(ByVal value As Integer)
            _Area_ID = value
        End Set
    End Property


    Private Sub Guardar_Nuevo_Empleado()

        'CapaDatos depende del nombre que ustedes le asignaron al proyecto.

        'Se llama al método Guardar_Nuevo_Empleado que se encuentra como estático en la 
        ' clase "Funciones_Empleado" de la capa de Datos.
        'Se envían los parámetros requeridos por el método.
        Me.Codigo = CapaDatos.Funciones_Empleado.Guardar_Nuevo_Empleado(Me.Nombre, Me.Apellido, Me.Edad, Me.Area_ID)

    End Sub

    Private Sub Actualizar_Empleado()

        'Se llama al método Actualizar_Empleado que se encuentra como estático en la 
        ' clase "Funciones_Empleado" de la capa de Datos.
        'Se envían los parámetros requeridos por el método.
        CapaDatos.Funciones_Empleado.Actualizar_Empleado(Nombre, Apellido, Edad, Codigo, Area_ID)

    End Sub

    Public Sub Guardar_Empleado()

        'Si el Código del empleado es igual a 0, entonces este objeto representa a un
        ' registro no existente y por lo tanto debe Insertarse, en caso contrario'
        ' el registro debe actualizarse.
        If Me.Codigo = 0 Then
            'Llamo al método Guardar_Nuevo_Empleado
            Me.Guardar_Nuevo_Empleado()
        Else
            'Llamo al método Actaulizar Empleado
            Actualizar_Empleado()
        End If


    End Sub
    

    Public Shared Function Buscar_Empleados() As DataTable

        'Hace un pasamanos para llamar a la funcion que devuelve un objeto
        ' DataTable de la capa de Datos.
        Return CapaDatos.Funciones_Empleado.Buscar_Empleados()

    End Function

    Public Shared Function Areas_De_La_Empresa() As DataTable

        'Hace un pasamanos para llamar a la funcion que devuelve un objeto
        ' DataTable de la capa de Datos.
        Return CapaDatos.Funciones_Empleado.Areas_Disponibles()

    End Function


    'Constructor vacio usado para dar de alta un nuevo registro de Empleados
    Public Sub New()

    End Sub

    'Constructor que recibe un código de empleado para construir un empleado 
    ' con datos de la base de datos.
    Public Sub New(ByVal codigo_empleado As Integer)

        'Obtiene una fila de la capa de Datos enviando el código recibido
        Dim fila = CapaDatos.Funciones_Empleado.Fila_De_Empleado(codigo_empleado)

        'Asigna los valores de esa fila a los atributos de la clase
        Me.Codigo = Convert.ToInt32(fila("codigo"))
        Me.Nombre = Convert.ToString(fila("nombre"))
        Me.Apellido = Convert.ToString(fila("apellido"))
        Me.Edad = Convert.ToInt32(fila("edad"))
        Me.Area_ID = Convert.ToInt32(fila("area_id"))
    End Sub

End Class
